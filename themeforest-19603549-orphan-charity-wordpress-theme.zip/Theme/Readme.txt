Thanks for purchase this awesome theme. 

Please read the documentation for install the theme. you will get the documentation in Documentation folder or 
look at http://bdthemes.com/support

Best Regards
Selim Rana // BdThemes Ltd