If you use demo import method so you don't need to import those slider again. 
Demo import automatically import all slider automatically.